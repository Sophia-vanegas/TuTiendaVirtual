import { useState } from 'react'
import Ejercicio1 from './Ejercicio1.jsx'
import Ejercicio2 from './Ejercicio2.jsx'
import Ejercicio3 from './Ejercicio3.jsx'

function App() {
  return (
    <>
      <h1>Taller React</h1>
      <Ejercicio1 />
      <Ejercicio2 />
      <Ejercicio3 />
    </>
  )
}

export default App

